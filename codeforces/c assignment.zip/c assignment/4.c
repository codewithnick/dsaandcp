#include <stdio.h>
int gcd(int a,int b){
    if(b<a){
        a=a^b;
        b=a^b;
        a=a^b;
    }
    while(a!=0 || b!=0){
        a=b%a;
    }
    return (a>b?a:b);
}
int main(){
int a,b;
printf("enter  2 numbers \n");
scanf("%d",&a);
scanf("%d",&b);
printf("the gcd is %d",gcd(a,b));
return 0;
}

